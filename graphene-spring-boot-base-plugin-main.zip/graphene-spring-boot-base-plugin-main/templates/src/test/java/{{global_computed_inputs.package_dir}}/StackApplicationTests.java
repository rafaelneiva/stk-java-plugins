package {{global_computed_inputs.base_package}};

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StackApplicationTests {

	@Test
	void contextLoads() {
	}
}
