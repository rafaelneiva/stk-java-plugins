### O Plugin gera um projeto Spring Boot base.
1. Permite escolher entre as versões 8, 11, ou 17 do Java.
2. Permite escoqlher Gradle ou Maven.
3. Executar a aplicação em um docker container.