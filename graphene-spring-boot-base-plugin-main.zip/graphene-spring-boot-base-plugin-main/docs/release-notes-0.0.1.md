The Plugin generates a Spring Boot project.
1. Allow choosing between Java versions 8, 11, or 17.
2. Allows choosing between Gradle or Maven.
3. Run the application in a docker container.