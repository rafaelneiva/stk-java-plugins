This Plugin starts a Spring Boot scaffolding project. It provides interactive inputs to initialize your project
according to the options below:

1. Spring Boot Version (2.7.2 or 3.0.1)
2. Build tool (Gradle or Maven)
3. Java version (8, 11, 17).
4. ArtifactId
5. Package Name

 

