Este Plugin inicializa um template de projeto Spring Boot. Fornece entradas interativas para iniciar o seu projeto
conforme as opções abaixo:

1. Versão do Spring Boot (2.7.2 or 3.0.1).
2. Ferramenta de build (Gradle or Maven).
3. Versão do java (8, 11, 17).
4. Id do artefato (ArtifactId).
5. Nome do pacote (Package Name).