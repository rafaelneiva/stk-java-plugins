## Before apply the plugin

- [**STK CLI**](https://docs.stackspot.com/home/stk-cli/install/)
- [**Java >= 8**](https://openjdk.org/)
- [**Git**](https://git-scm.com/)
- Java Spring Boot Project created
