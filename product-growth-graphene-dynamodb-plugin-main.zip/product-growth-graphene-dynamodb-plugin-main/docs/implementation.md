The Plugin generates/handle a project with the following structure:
```
├── pom.xml
└── src
│   └── main
│       └── java
│           └── br
│               └── com
│                   └── org
│                       └── projectname
│                           └── config
│                               └── DynamoDBConfig.java
│                               └── DynamoDBLocalConfig.java
```

- _DynamoDBConfig.java_: Configures the DynamoDB connection with AWS SDK and uses the Region input in the configuration.
- _DynamoDBLocalConfig.java_: Configures the DynamoDB connection with AWS SDK to use locally with the local profile.

### _pom.xml_ adds the following content:

**aws-java-sdk-sts**

```xml
<dependency>
  <groupId>com.amazonaws</groupId>
  <artifactId>aws-java-sdk-sts</artifactId>
  <version>1.12.550</version>
</dependency>
```

**aws-java-sdk-dynamodb**

```xml
<dependency>
    <groupId>com.amazonaws</groupId>
    <artifactId>aws-java-sdk-dynamodb</artifactId>
    <version>1.12.541</version>
</dependency>
```

**spring-data-dynamodb**

```xml
<dependency>
    <groupId>com.github.derjust</groupId>
    <artifactId>spring-data-dynamodb</artifactId>
    <version>5.1.0</version>
</dependency>
```

**DynamoDBLocal**

```xml
<dependency>
    <groupId>com.amazonaws</groupId>
    <artifactId>DynamoDBLocal</artifactId>
    <version>1.21.1</version>
    <scope>test</scope>
</dependency>
```

## Sample Case

The Plugin can generate a dynamo sample with the following structure:

```
└── src
│   └── main
│       └── java
│           └── {{global_computed_inputs.package_dir}}
│               └── sampledynamo
│                   └── controller
│                   └── dto
│                   └── entity
│                   └── exception
│                   └── repository
│                   └── service
```

The Plugin can generate a dynamo test using DynamoDBLocal with the following structure:

```
└── src
│   └── test
│       └── java
│           └── {{global_computed_inputs.package_dir}}
│               └── sampledynamo
│                   └── repository
```
