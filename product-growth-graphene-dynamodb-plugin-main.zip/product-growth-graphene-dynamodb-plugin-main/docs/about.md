## Graphene Dynamo Plugin

This Plugin creates a DynamoDB integration for Java Projects according to the options below:

1. Generate sample Dynamo Integration: True/False for generate a Java Dynamo integration sample
2. Table Name: DynamoDB table name to use in the generated sample (only available if generate sample is True)
3. AWS Region: Defines the region where the table should exist to DynamoDB Config 
