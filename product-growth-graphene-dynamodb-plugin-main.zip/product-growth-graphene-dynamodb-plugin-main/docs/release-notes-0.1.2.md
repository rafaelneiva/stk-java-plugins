# Release Notes 1.0.1

## Changed

_Nothing changed in this release_

## Fixed

_Nothing fixed in this release_

## Added

- Docs to explain how the plugin works
- Support for gradle and Spring Boot 2.7.2/3.0.1

## Removed

_Nothing removed in this release_
