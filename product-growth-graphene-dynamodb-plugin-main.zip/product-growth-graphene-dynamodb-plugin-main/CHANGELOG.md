# CHANGELOG

## 0.1.2 - 2023-10-27
[Release Notes 0.1.2](docs/release-notes-0.1.2.md)
