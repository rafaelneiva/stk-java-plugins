**Step 1.** Go to the root path of your Spring Boot project.  

**Step 2.** Execute the command below:  
If the Plugin is within a Stack in the Workspace, execute the command below:
> This is an example. Replace the content between <> according to the Studio information:
   ```bash
      stk apply plugin <studio-name>/<stack-name>/metrics-plugin
   ```

If the Plugin isn't in a Workspace, and you're doing remote tests, execute the command below:
> This is an example. Replace the content between <> according to your Account and Studio information.
   ```bash
      stk apply plugin <account-name>/<studio-name>/<stack-name>/metrics-plugin
   ```

**Step 3.** Add the information
- If you have a project structure created with StackSpot, you don't need to inform anything.
- If you didn't create your application via StackSpot, add the following information:  
  - **Project name**
  - **Spring Boot version**
  - **Java version**
  - **Project artifact ID**
  - **Project group ID.**  Don't add the project's name at the end of the group ID. StackSpot already requested this information via the input you informed.

**Step 4.** Build the project according to your OS:
- Linux
    ```bash
    #Maven:
      ./mvnw clean install
    #OR Gradle
      ./gradlew build
    ```
- Windows
    ```bash
    #Maven: 
        mvnw clean install**
    #OR Gradle: 
        gradlew build
    ```

**Step 5.** Run the application via docker-compose:
- Run the command below to put the container up:
    ```bash
        docker compose up --build --wait
    ``` 
- Put container down:
    ```bash
       docker compose down
    ```

**Step 6.** Access the tracing information:
- Access the health endpoint through de address: http://localhost:8080/actuator/health
- Access the metrics endpoint through de address: http://localhost:8080/actuator/metrics
  - Choose any information from the returned metrics endpoint above and get more details as follow. E.g: http://localhost:8080/actuator/metrics/jvm.memory.max
