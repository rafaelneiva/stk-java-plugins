To use this Plugin, install the following items:
- [**STK CLI**](https://docs.v1.stackspot.com/platform-content/stk-cli/install/)
- [**Java**](https://openjdk.org/)
- [**Git**](https://git-scm.com/)
- [**docker >= 20.10.12**](https://docs.docker.com/engine/install/)
- [**docker compose >= v2.11.2**](https://docs.docker.com/compose/install/)
