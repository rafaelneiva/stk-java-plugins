Esse Plugin adiciona a dependência do Spring Boot Actuator no seu projeto.

### A dependência será adicionada conforme a sua ferramenta de build (*build tool*) utilizada no seu projeto. Ex:

---
- Ferramenta de build (Build Tool) Gradle
```gradle
    implementation 'org.springframework.boot:spring-boot-starter-actuator'
```

- Ferramenta de build (Build Tool) Maven
```xml
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-actuator</artifactId>
   </dependency>
```

### O pluguin adiciona o techo de código abaixo no arquivo *application.yaml* do seu projeto para habilitar o acesso aos endpoints *health* e *metrics*. Ex:

---
```yaml
  management:
      endpoints:
        web:
          exposure:
            include: health, metrics  
```