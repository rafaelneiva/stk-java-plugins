This Plugin adds the functionality to obtain metrics information from your application using Spring Boot Actuator.

Check at the documentation below on how to customize your metrics information using Spring Boot Actuator:
- Use the guide Spring Boot Actuator official doc:
  - [**Example 1**](https://docs.spring.io/spring-boot/docs/2.0.x/actuator-api/html/)
  - [**Example 2**](https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/#actuator.endpoints)
- Use guide [**Baeldung**](https://www.baeldung.com/spring-boot-actuators)
- Use guide [**Zup**](https://www.zup.com.br/blog/spring-actuator) 