Release Notes 0.0.1
Application monitoring using Spring Boot Actuator