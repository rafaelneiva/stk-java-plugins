Esse Plugin adiciona a capacidade de obter informações de métricas da sua aplicação usando o Spring Boot Actuator.

Verifique na documentação abaixo como customizar as suas informações de métricas usando Spring Boot Actuator.
- Guia de uso oficial Spring Boot Actuator:
    - [**Example 1**](https://docs.spring.io/spring-boot/docs/2.0.x/actuator-api/html/)
    - [**Example 2**](https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/#actuator.endpoints)
- Guia de uso [**Baeldung**](https://www.baeldung.com/spring-boot-actuators)
- Guia de uso [**Zup**](https://www.zup.com.br/blog/spring-actuator) 