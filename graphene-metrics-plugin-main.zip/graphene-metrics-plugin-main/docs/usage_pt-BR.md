**Passo 1.** Navegue até a raiz do seu projeto Spring Boot.

**Passo 2.** Execute o comando abaixo:
Se o Plugin estiver em uma Stack atrelada a um Workspace, execute o comando abaixo:
> Segue um exemplo. Substitua o conteúdo entre <> conforme as informações do Estúdio.
   ```bash
      stk apply plugin <studio-name>/<stack-name>/metrics-plugin
   ```

Se o Pugin não está associado a um Workspace e você estiver realizando testes remotos; execute o comando abaixo:
>  Abaixo é um exemplo. Substitua o conteúdo entre <> conforme as informações da Account e Studio.
   ```bash
      stk apply plugin <account-name>/<studio-name>/<stack-name>/metrics-plugin
   ```

**Passo 3.** Preencha as informações requisitadas.
- Se a estrutura inicial do seu projeto foi criada com a Stackspot, você não precisa preencher nenhuma informação.
- Se a sua aplicação não foi criada com a Stackspot, você deve preencher as seguintes informações:
  - **Nome do projeto**
  - **Versão do Spring Boot**
  - **Versão do Java**
  - **Project artifact ID** (Identificador do artefato do projeto).
  - **Project group ID** (Grupo identificador do projeto). Não informe o nome do projeto no final do group ID, porque a StackSpot já solicitou essa informação por meio do input informado anteriormente.

**Passo 4.** Construa o projeto (Build the project) de acordo com seu sistema operacional:
- Linux
    ```bash
    #Maven:
      ./mvnw clean install
    #OR Gradle
      ./gradlew build
    ```
- Windows
    ```bash
    #Maven: 
        mvnw clean install**
    #OR Gradle: 
        gradlew build
    ```

**Passo 5.** Execute a aplicação com o docker-compose
- Suba o container:
    ```bash
        docker compose up --build --wait
    ``` 
- E pare o container com o comando:
    ```bash
       docker compose down
    ```

**Passo 6.** Acesse as informações de tracing
- Acesso o endpoint *health* através do endereço: http://localhost:8080/actuator/health 
- Acesso o endpoint *metrics* através do endereço: http://localhost:8080/actuator/metrics
  - Escolha qualquer uma informação de métrica retornada através do endpoint acima e obtenha mais detalhes da seguinte forma. Ex: http://localhost:8080/actuator/metrics/jvm.memory.max

