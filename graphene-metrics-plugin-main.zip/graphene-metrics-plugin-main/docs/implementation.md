This plugin adds the Spring Boot Actuator dependency to your project.

### The dependency will be added according to the defined build tool in your project. E.g:

---
- Build Tool Gradle
```gradle
    implementation 'org.springframework.boot:spring-boot-starter-actuator'
```

- Build Tool Maven
```xml
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-actuator</artifactId>
   </dependency>
```

### The plugin adds the code snippet below to your project's  *application.yaml* file to enable access to the *health* and *metrics* endpoints. e.g:

---
```yaml
  management:
      endpoints:
        web:
          exposure:
            include: health, metrics  
```