# Release Notes 1.0.0

## Changed

_Nothing changed in this release_

## Fixed

_Nothing fixed in this release_

## Added

- Snippets with dependencies for Gradle and Maven
- Inputs: project_name, project_artifact_id, project_group_id, build_tool, main_file_name, generate_feign
- Global Computed Inputs: base_package, package_dir
- Hooks
  - to render the minimum need to OpenFeign executes
  - to generate a sample Feign Client based on input
- bug report and feature form template issues

## Removed

_Nothing removed in this release_
