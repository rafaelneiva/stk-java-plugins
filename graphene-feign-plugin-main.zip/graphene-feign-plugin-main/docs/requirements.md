To use this plugin, you need to install the following items:
- [**STK CLI**](https://docs.stackspot.com/content-creator/stk-cli/install/)
- [**Java**](https://openjdk.org/)
- [**Git**](https://git-scm.com/)
- [**docker >= 20.10.12**](https://docs.docker.com/engine/install/)
