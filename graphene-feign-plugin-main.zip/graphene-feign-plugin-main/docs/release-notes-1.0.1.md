# Release Notes 1.0.1

## Changed

_Nothing changed in this release_

## Fixed

- fix dependency version based on spring boot version

## Added

_Nothing added in this release_

## Removed

_Nothing removed in this release_
