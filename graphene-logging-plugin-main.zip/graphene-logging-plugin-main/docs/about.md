This Plugin generates execution logs from the application and enables configuring the log output format and log level for each environment the application is running.
