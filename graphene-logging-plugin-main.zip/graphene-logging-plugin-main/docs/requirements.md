To use this Plugin, install the following items:
- [**STK CLI**](https://docs.v1.stackspot.com/platform-content/stk-cli/install/)
- [**Java**](https://openjdk.org/)
- [**Git**](https://git-scm.com/)
