Este Plugin gera logs de execução do aplicativo e permite configurar o formato de saída do log e o nível do log para cada ambiente em que o aplicativo está sendo executado.
